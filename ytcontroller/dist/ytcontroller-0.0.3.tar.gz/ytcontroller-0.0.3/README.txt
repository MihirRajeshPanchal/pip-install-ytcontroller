Youtube Controller through hand gestures

Functions : 

multiple_clicker(key1, key2)

clicker(key)

ytcontrol()

Gesture names-Functions :  

Rock Sign-FullScreen

Fist-Forward

Victory Sign-Rewind

Thumbs Up-Volume Up

Thumbs Down-Volume Down

Okay Sign-Play/Pause